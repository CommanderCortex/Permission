package cortex.main;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;

public class EvHandler implements Listener {
	FileHandler FileHandler = new FileHandler();
	RankHandler RankHandler = new RankHandler();
	PlayerHandler PlayerHandler = new PlayerHandler();
	Commands Commands = new Commands();
	
	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent e){
		System.out.println(e.getPlayer().getName());
		Player p = e.getPlayer();
		PlayerHandler.SetupPlayer(p);
	}
	@EventHandler
	public void onPlayerChat(AsyncPlayerChatEvent e) {
		e.setCancelled(true);
		Player p = e.getPlayer();
		String name = p.getDisplayName();
		String prefix = RankHandler.getRankPrefix(RankHandler.getRank(p));
		String message = e.getMessage();
		Bukkit.broadcastMessage(prefix + name + ">> " + message);
	}

}

		


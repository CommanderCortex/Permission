package cortex.main;

import org.bukkit.Bukkit;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;


public class Main extends JavaPlugin implements Listener{
	
	FileHandler FileHandler = new FileHandler();
	RankHandler RankHandler = new RankHandler();
	PlayerHandler PlayerHandler = new PlayerHandler();
	EvHandler EvHandler = new EvHandler();
	Commands Commands = new Commands();
	
	@Override
	public void onEnable() {
		getCommand(Commands.fly).setExecutor(Commands);
		getCommand(Commands.setrank).setExecutor(Commands);
		Bukkit.broadcastMessage("Cortex Perms Ver: 1.5.7");
		getServer().getPluginManager().registerEvents(EvHandler, this);
		FileHandler.Setup();

	}
	@Override
	public void onDisable() {
	}
	
}
	


package cortex.main;

import java.io.File;
import java.io.IOException;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

public class RankHandler {
	String CortexPlayerData = "Cortex/Main/PlayerData";

	FileHandler FileHandler = new FileHandler();
	PlayerHandler PlayerHandler = new PlayerHandler();
	EvHandler EvHandler = new EvHandler();
	Commands Commands = new Commands();
	
	int Owner = 100;
	int Manager = 90;
	int HeadAdmin = 85;
	int Admin = 80;
	int Dev = 70;
	int JrDev = 65;
	int SrMod = 60;
	int Mod = 50;
	int Helper = 45;
	int Trainee = 40;
	int None = 0;
	
	public int getRank(Player p) {
		File pd = new File(CortexPlayerData + p.getUniqueId() + ".yml" );
		YamlConfiguration yml = YamlConfiguration.loadConfiguration(pd);
		return yml.getInt("Rank");
	}
	
	public String getRankPrefix(int Rank){
		if(Rank == Owner) {
			return ChatColor.DARK_RED.toString() + ChatColor.BOLD + "Owner " + ChatColor.RESET;		
		}else if(Rank == Admin) {
			return ChatColor.DARK_RED.toString() + ChatColor.BOLD + "Admin " + ChatColor.RESET;		
		}else if(Rank == Mod) {
			return ChatColor.GOLD.toString() + ChatColor.BOLD + "Mod " + ChatColor.RESET;		
		}else if(Rank == Manager) {
			return ChatColor.DARK_RED.toString() + ChatColor.BOLD + "Manager " + ChatColor.RESET;
		}else if(Rank == HeadAdmin) {
			return ChatColor.DARK_RED.toString() + ChatColor.BOLD + "H.Admin" + ChatColor.RESET;
		}else if(Rank == Dev) {
			return ChatColor.DARK_PURPLE.toString() + ChatColor.BOLD + "Dev" + ChatColor.RESET;
		}
		return "";
	}
	
	public void refreashRanks() {
		for(Player p : Bukkit.getOnlinePlayers()) {
		Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
		for(Player pl : Bukkit.getOnlinePlayers()){
			String prefix = getRankPrefix(getRank(pl));
			Team team = board.registerNewTeam(pl.getDisplayName());
			team.setPrefix(prefix);
			team.addEntry(pl.getName());
		}
		p.setScoreboard(board);
		}
	
	}
	public boolean setRank(Player p, int rank) {
		File pd = new File(CortexPlayerData + p.getUniqueId() + ".yml" );
		YamlConfiguration yml = YamlConfiguration.loadConfiguration(pd);
		yml.set("rank", rank);
		try {
			yml.save(pd);
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
}

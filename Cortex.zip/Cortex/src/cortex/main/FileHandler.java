package cortex.main;

import java.io.File;

public class FileHandler {
	
	RankHandler RankHandler = new RankHandler();
	PlayerHandler PlayerHandler = new PlayerHandler();
	EvHandler EvHandler = new EvHandler();
	Commands Commands = new Commands();
	
	String Cortex = "Cortex";
	String CortexMain = "Cortex/Main";
	String CortexPlayerData = "Cortex/Main/PlayerData";
	
	 public void Setup() {
		 File MainDIR = new File(CortexMain);
		 if (!MainDIR.exists()) {
			 MainDIR.mkdir();
		 }
		 File PlayerData = new File(CortexPlayerData);
		 if (!PlayerData.exists()){
			 PlayerData.mkdir();
		 }
		 File RanksDIR = new File(CortexMain + "/Ranks");
		 if (!RanksDIR.exists()) {
			 RanksDIR.mkdir();
		 }
		 File RandomDIR = new File(Cortex + "/etc");
		 if (!RandomDIR.exists()) {
			 RandomDIR.mkdir();
		 }
	}


}

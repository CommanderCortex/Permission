package cortex.main;

import java.io.File;
import java.io.IOException;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public class PlayerHandler {
	String CortexPlayerData = "Cortex/Main/PlayerData/";
	
	FileHandler FileHandler = new FileHandler();
	RankHandler RankHandler = new RankHandler();
	EvHandler EvHandler = new EvHandler();
	Commands Commands = new Commands();
	
	public void SetupPlayer(Player p){
		File pd = new File(CortexPlayerData + p.getUniqueId() + ".yml" );
		if (!pd.exists()) {
			try {
				pd.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		YamlConfiguration yml = YamlConfiguration.loadConfiguration(pd);
		yml.addDefault("Name", p.getName());
		yml.addDefault("Rank", RankHandler.None);
		yml.options().copyDefaults(true);
		try {
			yml.save(pd);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
